﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _7.QuotesInStrings
{
    class QuotesInStrings
    {
        static void Main(string[] args)
        {
            string backSlash = "The \"use\" of quotations causes difficulties.";
            string at = @"The ""use"" of quotations causes difficulties.";
            Console.WriteLine(backSlash + "\n" + at);

        }
    }
}
