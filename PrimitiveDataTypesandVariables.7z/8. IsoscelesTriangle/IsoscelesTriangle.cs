﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _8.IsoscelesTriangle
{
    class IsoscelesTriangle
    {

        static void Main(string[] args)
        {
            Console.OutputEncoding = Encoding.UTF8;
            char copyright = '\u00A9';
            Console.WriteLine(" " + " " + " " + copyright + "\n" + " " + " " + copyright + " " + copyright + "\n" + " " + copyright + " " + " " + " " + copyright + "\n" + copyright + " " + copyright + " " + copyright + " " + copyright);

        }
    }
}
