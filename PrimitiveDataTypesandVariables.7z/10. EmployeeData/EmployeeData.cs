﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _10.EmployeeData
{
    class EmployeeData
    {
        static void Main(string[] args)
        {
            string firstName = "Rosen";
            string lastName = "Georgiev" ;
            sbyte Age = 25;
            char Gender = 'm';
            long PersonalID = 8306112507;
            int UEN = 27560000;
            Console.WriteLine("First Name: " + firstName + "\n" + "Last Name: " + lastName + "\n" + "Age: " + Age + "\n" + "Gender: " + Gender + "\n" + "Personal ID: " + PersonalID + "\n" + "Unique Employee Number: " + UEN);

        }
    }
}
