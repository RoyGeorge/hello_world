﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2.FloatOrDouble
{
    class FloatOrDouble
    {
        static void Main(string[] args)
        {
            double realOne = 34.567839023;
            float realTwo = 12.345f;
            double realThree = 8923.1234857;
            float realFour = 3456.091f;
            Console.WriteLine(realOne + "\n" + realTwo + "\n" + realThree + "\n" + realFour);
        }
    }
}
