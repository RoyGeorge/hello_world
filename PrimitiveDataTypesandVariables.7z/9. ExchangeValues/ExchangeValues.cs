﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _9.ExchangeValues
{
    class ExchangeValues
    {
        static void Main(string[] args)
        {
            int a, b;
            a = 5;
            b = 10;
            Console.WriteLine(a + "\n" + b);
            a = a + b;
            b = a - b;
            a = a - b;
            Console.WriteLine(a.ToString());
            Console.WriteLine(b.ToString());
            Console.ReadLine();
            

            



        }
    }
}
