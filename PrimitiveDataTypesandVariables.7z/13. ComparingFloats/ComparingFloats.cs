﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _13.ComparingFloats
{
    class ComparingFloats
    {
        static void Main(string[] args)
        {
            double double1 = .333333;
            double double2 = (double) 1/3;
            double difference = Math.Abs(double1 * .000001);
            if (Math.Abs(double1 - double2) <= difference)
                Console.WriteLine("double1 and double2 are equal.");
            else
                Console.WriteLine("double1 and double2 are unequal.");

        }
    }
}
