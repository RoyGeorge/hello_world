﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _12.NullValues
{
    class NullValues
    {
        static void Main(string[] args)
        {
            int? one = null;
            Nullable<double> two = null;
            Console.WriteLine(one + "\n" + two);
            int numb = 5;
            one = numb;
            Console.WriteLine(one);





        }
    }
}
