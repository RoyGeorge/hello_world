﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _11.BankData
{
    class BankData
    {
        static void Main(string[] args)
        {
            string firstName;
            string middleName;
            string lastName;
            decimal balance;
            string bankName;
            long IBAN;
            long creditCard1;
            long creditCard2;
            long creditCard3;
        }
    }
}
