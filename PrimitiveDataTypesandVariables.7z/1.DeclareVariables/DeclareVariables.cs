﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1.DeclareVariables
{
    class DeclareVariables
    {
        static void Main(string[] args)
        {
            sbyte firstNum = -115;
            byte secondNum = 97;
            short thirdNum = - 10000;
            ushort fourthNum = 52130;
            int fifthNum = 4825932;
           


        }
    }
}
