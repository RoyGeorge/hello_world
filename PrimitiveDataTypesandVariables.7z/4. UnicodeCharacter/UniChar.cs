﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _4.UnicodeCharacter
{
    class UniChar
    {
        static void Main(string[] args)
        {
            char uniChar = '\u002A';
            Console.WriteLine(uniChar);
        }
    }
}
