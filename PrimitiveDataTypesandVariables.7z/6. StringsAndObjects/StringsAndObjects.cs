﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _6.StringsAndObjects
{
    class StringsAndObjects
    {
        static void Main(string[] args)
        {
            string hello = "Hello";
            string world = "World";
            object concat = hello + " " + world;
            string helloWorld = (string)concat;
            Console.WriteLine(helloWorld);




        }
    }
}