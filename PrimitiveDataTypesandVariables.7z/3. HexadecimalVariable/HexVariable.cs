﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _3.HexadecimalVariable
{
    class HexVariable
    {
        static void Main(string[] args)
        {
            int hexVariable = 0xFE;
            Console.WriteLine(hexVariable);
        }
    }
}
